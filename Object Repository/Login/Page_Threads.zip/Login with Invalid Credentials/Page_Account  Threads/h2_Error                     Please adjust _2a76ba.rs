<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Error                     Please adjust _2a76ba</name>
   <tag></tag>
   <elementGuidId>a78e8733-97b2-4f6c-aa1b-f9aa6a1cbea8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h2.form__message</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='customer_login']/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Error Please adjust the following:&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>37812be8-3744-4ec6-b6c1-198b4798f4bf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form__message</value>
      <webElementGuid>74bcf375-ceb3-493d-ae36-469b219c0ab0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
      <webElementGuid>1c34b54e-0725-44c5-9693-8a333a76c474</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
          Error 
          

          Please adjust the following:
        </value>
      <webElementGuid>d8158a7e-402a-4b18-952d-912d6b290ee9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customer_login&quot;)/h2[@class=&quot;form__message&quot;]</value>
      <webElementGuid>0c4296a1-c572-486c-bd05-0b868deeadc7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='customer_login']/h2</value>
      <webElementGuid>2eb44f38-b543-4d00-8921-6518d9f3e308</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/following::h2[1]</value>
      <webElementGuid>df2d680a-a461-4dc9-8307-ad402fdc57ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::h2[1]</value>
      <webElementGuid>7011eff4-4d9e-441a-85b3-8155e045bece</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Incorrect email or password.'])[1]/preceding::h2[1]</value>
      <webElementGuid>cb108086-6c61-48a5-9069-d6bc0617391e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Please adjust the following:']/parent::*</value>
      <webElementGuid>5f9a63b0-10c7-46f2-83cf-b3102916fcf6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/h2</value>
      <webElementGuid>07f8080a-9b62-47f6-9105-502ed67b6d90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = '
          Error 
          

          Please adjust the following:
        ' or . = '
          Error 
          

          Please adjust the following:
        ')]</value>
      <webElementGuid>cd28a42b-c378-4dd2-a883-c85ba068f11b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
