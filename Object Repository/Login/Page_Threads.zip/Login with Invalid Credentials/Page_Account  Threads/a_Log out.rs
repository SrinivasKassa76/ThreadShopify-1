<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Log out</name>
   <tag></tag>
   <elementGuidId>84116074-3e7c-4e75-8a54-204ec209ada0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.customer.account.section-template--18610481135839__main-padding > div > a</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='shopify-section-template--18610481135839__main']/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Log out&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>92b78968-635e-479f-b911-8d7a39b56fca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/account/logout</value>
      <webElementGuid>ebd3b8e7-5d8e-4846-b6d3-0eeef3ccc88d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      

      Log out
    </value>
      <webElementGuid>7b821179-b6cd-4ff6-ac16-c750ca2bfded</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;shopify-section-template--18610481135839__main&quot;)/div[@class=&quot;customer account section-template--18610481135839__main-padding&quot;]/div[1]/a[1]</value>
      <webElementGuid>2aab0935-fc50-40e3-b25a-d36ee0a91030</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='shopify-section-template--18610481135839__main']/div/div/a</value>
      <webElementGuid>f29fd6d1-ad93-4919-bfa5-d8b995decfc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account'])[3]/following::a[1]</value>
      <webElementGuid>fe50eaae-cf29-4559-b8e0-fb878cb954ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue shopping'])[1]/following::a[1]</value>
      <webElementGuid>1e88147d-7ade-4e51-821e-89438ada45a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order history'])[1]/preceding::a[1]</value>
      <webElementGuid>0ee94dc7-095c-4d7e-b4ae-777ead46812d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Order history'])[2]/preceding::a[1]</value>
      <webElementGuid>55b06199-769d-4e4d-9c03-a706fbdc344f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Log out']/parent::*</value>
      <webElementGuid>27410579-0881-496b-a202-e2ee90cd18f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/account/logout')]</value>
      <webElementGuid>f8ca5063-be61-4ad9-954d-8f1fefcb9415</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div/a</value>
      <webElementGuid>966ebd92-c3a9-46f6-90e6-55d54d5b3f93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/account/logout' and (text() = '
      

      Log out
    ' or . = '
      

      Log out
    ')]</value>
      <webElementGuid>ee5e0086-7d19-41ee-ab78-595f7cbb5930</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
