<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Incorrect email or password</name>
   <tag></tag>
   <elementGuidId>952d67ab-1b99-43bb-a001-d55c77d3398f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.errors > ul > li</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='customer_login']/div/ul/li</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Incorrect email or password.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>775b3952-a3a1-4479-ba4e-6609a64c41c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Incorrect email or password.</value>
      <webElementGuid>2b133b1f-c2db-483e-ba03-52a593c9ab12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customer_login&quot;)/div[@class=&quot;errors&quot;]/ul[1]/li[1]</value>
      <webElementGuid>8675c851-69c1-4c66-a036-2708e0671c27</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='customer_login']/div/ul/li</value>
      <webElementGuid>39fd7fee-1c3a-4aa1-98bc-b530e3fb25dc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Error'])[1]/following::li[1]</value>
      <webElementGuid>8793fee4-f569-4ba6-a09a-758b0fc2b54a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[2]/preceding::li[1]</value>
      <webElementGuid>787faf12-bcd1-43fc-972f-73998853cc1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/preceding::li[1]</value>
      <webElementGuid>d469ccca-670a-41a1-96e7-2129d6b76fcd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Incorrect email or password.']/parent::*</value>
      <webElementGuid>dd28b494-7c40-4389-8d3b-b2c42a42eca8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div/ul/li</value>
      <webElementGuid>737e081b-2897-43ac-b42c-845a64d04a08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Incorrect email or password.' or . = 'Incorrect email or password.')]</value>
      <webElementGuid>4666169b-26d3-4bbc-9cc2-34ae437db15b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
