<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Alice CenaPursuitabc apartment, xyz road7_dc2c2a</name>
   <tag></tag>
   <elementGuidId>db07bec4-cef1-4ceb-8b12-cfa815f9e97d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='shopify-section-template--18610481135839__main']/div/div[2]/div[2]/p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Alice CenaPursuitabc apartment, xyz road700001 Kolkata WBIndia&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>38846c13-1411-458a-a886-ae784da404bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Alice CenaPursuitabc apartment, xyz road700001 Kolkata WBIndia</value>
      <webElementGuid>e62230c2-ff5b-47b0-965f-bfd8cea85b59</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;shopify-section-template--18610481135839__main&quot;)/div[@class=&quot;customer account section-template--18610481135839__main-padding&quot;]/div[2]/div[2]/p[1]</value>
      <webElementGuid>bfeca7e5-9f72-45f5-a7c1-3748904cbae5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='shopify-section-template--18610481135839__main']/div/div[2]/div[2]/p</value>
      <webElementGuid>e35fe6af-96e7-4d53-94b0-8de2e09666bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account details'])[1]/following::p[1]</value>
      <webElementGuid>db2162ea-dd44-491f-9966-53ecc95c2368</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Rs. 66.08'])[1]/following::p[1]</value>
      <webElementGuid>27614d80-9684-44e6-8ccc-2887120634e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View addresses (1)'])[1]/preceding::p[1]</value>
      <webElementGuid>f926a568-8e29-4088-8adc-b695fed4a1ef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get exclusive offers'])[1]/preceding::p[1]</value>
      <webElementGuid>0fbeabd5-97b5-44c3-9d26-a8afb3d8d918</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Alice Cena']/parent::*</value>
      <webElementGuid>b28cdc3a-4c72-4416-91f4-45b315168205</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>8471a817-c64d-4b58-b9af-4be15fd1f7b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Alice CenaPursuitabc apartment, xyz road700001 Kolkata WBIndia' or . = 'Alice CenaPursuitabc apartment, xyz road700001 Kolkata WBIndia')]</value>
      <webElementGuid>f351d12b-d0d3-4b03-b624-86511e5760aa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
