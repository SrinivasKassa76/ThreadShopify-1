<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Enter using password</name>
   <tag></tag>
   <elementGuidId>61d86ccf-564f-403b-b965-c0e4bb31ae56</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.modal__toggle-open.password-link.link.underlined-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='shopify-section-main-password-header']/div/div/password-modal/details/summary/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;Enter using password&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>84f69af2-9eec-44b1-8d0d-5656553ab463</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal__toggle-open password-link link underlined-link</value>
      <webElementGuid>7a1646e2-4ed5-4c17-a998-305c7dea0fc8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            

            Enter using password
          </value>
      <webElementGuid>4d39631f-c98d-4506-9577-26d2490beae2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;shopify-section-main-password-header&quot;)/div[@class=&quot;color-scheme-1 gradient&quot;]/div[@class=&quot;password-header&quot;]/password-modal[1]/details[@class=&quot;password-modal modal&quot;]/summary[@class=&quot;modal__toggle&quot;]/div[@class=&quot;modal__toggle-open password-link link underlined-link&quot;]</value>
      <webElementGuid>20fd5072-62f2-4297-9eac-3819bf8b834f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='shopify-section-main-password-header']/div/div/password-modal/details/summary/div</value>
      <webElementGuid>50590fa7-c504-4f2b-9610-5ad258330f43</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Skip to content'])[1]/following::div[4]</value>
      <webElementGuid>131acd43-b710-4e3b-a116-77dbabe060a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter store using password:'])[1]/preceding::div[2]</value>
      <webElementGuid>ad0905bb-c2e5-44b9-9d7e-9745c2a548b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your password'])[1]/preceding::div[2]</value>
      <webElementGuid>b4c9da82-facd-4c70-a1b5-7f5ee4d3b2f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Enter using password']/parent::*</value>
      <webElementGuid>2200f4b1-fea6-4726-9d2c-7deb5b53d6e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//summary/div</value>
      <webElementGuid>30b7e6a2-67f4-4a0d-9007-5bb6c78df5d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
            

            Enter using password
          ' or . = '
            

            Enter using password
          ')]</value>
      <webElementGuid>27b425aa-2355-43a5-8460-a5fa0abf5581</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
